
<?php
require 'conx.php';

function send($conx,$query,$elem){

	$stmt = $conx->prepare($query);

	$stmt->execute(array());

	// $stmt = $conx->setFetchMode(PDO::FETCH_OBJ);

	$res = $stmt->fetchAll(PDO::FETCH_OBJ);

	if (!empty($res)) {
		
		return $res;
	}else{
		return 'false';
	}
	
}

function check($conx,$query){

	$stmt = $conx->prepare($query);

	$stmt->execute();

	// $stmt = $conx->setFetchMode(PDO::FETCH_OBJ);

	$res = $stmt->fetchAll(PDO::FETCH_OBJ);

	if (!empty($res)) {
		
		return $res;
	}else{
		return 'false';
	}
	
}

function insert($conx,$query,$elem){

	$stmt = $conx->prepare($query);

	$stmt->execute($elem);

	if ($stmt) {
		
		return 'good';
	}else{
		return 'false';
	}
	
}
