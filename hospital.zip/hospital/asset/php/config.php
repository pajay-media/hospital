<?php


$config = [

	'username' => 'root',

	'password' => ''

];