<?php 
require 'conx.php';
//include 'php/utility.php';
function query($query, $bindings, $conx)
{
	$stmt = $conx->prepare($query);
	$stmt->execute($bindings);

	$results = $stmt->fetchAll(PDO::FETCH_OBJ);

	return $results ? $results : false;
}

function query_assoc($query, $bindings, $conx)
{
	$stmt = $conx->prepare($query);
	$stmt->execute($bindings);

	$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

	return $results ? $results : false;
}

function get($tableName, $conx)
{
	try {
		$result = $conx->query("SELECT * FROM $tableName");

		return ( $result->rowCount() > 0 )
			? $result
			: false;
	} catch(Exception $e) {
		return false;
	}

}

function getmod($tableName, $conx)
{
	try {
		$result = $conx->query("SELECT * FROM $tableName");

		return ( $result->rowCount() > 0 )
			? $result
			: false;
	} catch(Exception $e) {
		return false;
	}

}

function if_exists($tablename, $conx, $checker, $parameter)
{
	$query = "SELECT * FROM $tablename WHERE $parameter = :checker";
	$result = $conx->prepare($query);
	$result->execute($checker);

	return ( $result->rowCount() > 0)
		? 'exists'
		: 'false';
}

function activate($tablename, $id_num, $conn)
{
	$result = $conn->query("UPDATE admin SET status = 1 WHERE id_num = $id_num ");
}
function change_password($conx,$elem)
{
	$result = $conx->prepare("UPDATE admin SET password = :password WHERE post = :post");

	$result->execute($elem);

	return ( $result)
			? true
			: false;
}
function getLimit($tableName, $conx, $limit = 10)
{
	try {
		$result = $conx->query("SELECT * FROM $tableName ORDER BY id DESC LIMIT $limit");

		return ( $result->rowCount() > 0 )
			? $result
			: false;
	} catch(Exception $e) {
		return false;
	}
}
function delete($tablename, $value, $conx)
{
	$query = $conx->prepare("DELETE FROM $tablename WHERE id = :id ORDER BY id ASC LIMIT 1");
	$query-> bindParam(':id', $value, PDO::PARAM_STR);
	$query->execute();

	return ( $query)
			? true
			: false;
	// else
}
function single($query, $column, $value, $conx)
{
	$single = $conx->prepare($query);
	$single->bindParam($column, $value, PDO::PARAM_STR);
	$single->execute();

	$results = $single->fetchAll(PDO::FETCH_OBJ);

	return $results ? $results : false;
}
function getLimitParam($tableName, $conx, $limit = 10, $parameter, $checker)
{
	try {
		$result = $conn->query("SELECT * FROM $tableName ORDER BY id DESC LIMIT $limit WHERE $parameter = $checker");

		return ( $result->rowCount() > 0 )
			? $result
			: false;
	} catch(Exception $e) {
		return false;
	}
}

function get_by_id_num($value, $conx)
{
	$query = query(
		'SELECT id_num, password FROM student WHERE id_num = :id_num LIMIT 1',
		array('id_num' => $value),
		$conx
	);

	return ( $query)
			? $query
			: false;
	// else
}

function get_spec_param($value, $conx, $tablename)
{
	$query = query(
		"SELECT password FROM $tablename WHERE post = :post LIMIT 1",
		array('post' => $value),
		$conx
	);

	return ( $query)
			? $query
			: false;
	// else
}

function insert($conx,$query,$elem)
{

	$stmt = $conx->prepare($query);

	$stmt->execute($elem);

	
	if ($stmt) {
		
		return 'true';
	}else{
		return false;
	}
	
}
