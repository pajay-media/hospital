<?php

require 'config.php';

try {
	
	$conx =  new PDO('mysql:host=localhost;dbname=medication',$config['username'],$config['password']);

	$conx->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

	return $conx;

} catch (PDOException $e) {

	echo "connection failed" . $e->getMessage();

}



?>