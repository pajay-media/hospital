var mes = _('.mes');
	_('.id').onkeyup = function(){

		var xml =  window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject("Microsoft.XMLHTTP");

		 var elem = new FormData();
		elem.append("id", _('.id').value);

		xml.onreadystatechange = function(){
			if (xml.readyState == 4) {
				
				mes.innerHTML = xml.response;
				 
				  // console.log(xml.responseText.length);
				if (xml.responseText.length > 20) {
					
					mes.innerHTML = xml.responseText;
					console.log(xml);
				}
			}else{
				//console.log('not working');
			}
		}		
		xml.open('POST', 'smallPhp/search.php');
		xml.send(elem);
		console.log(_('.id').value);
	}
	