_('.logout').onclick = function(e){
		if(confirm('do you want to log out from this page')==true){
		var xml =  window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject("Microsoft.XMLHTTP");

		xml.onreadystatechange = function(){
			if (xml.readyState == 4) {
				
				if (xml.responseText.length < 9) {
					window.location = 'index.php';
					}
			}else{
				console.log('not working');
			}
		}		
		xml.open('POST', 'smallPhp/logout.php');
		xml.send();
	}
	else{
		
	}
}