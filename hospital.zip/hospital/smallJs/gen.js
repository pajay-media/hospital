function _(elem){

		var file = document.querySelector(elem);
		return file;
	}
