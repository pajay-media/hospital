var xml =  window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject("Microsoft.XMLHTTP");

		xml.onreadystatechange = function(){
			if (xml.readyState == 4) {
				 // console.log(xml.response);
				mes.innerHTML = xml.response;
				 // console.log(xml.response);
				  console.log(xml.responseText.length);
				if (xml.responseText.length < 9) {
					
					mes.innerHTML = 'Your Article has been successfully posted';
					

	
					 setTimeout('reset()', 5000);
				}
			}else{
				console.log('not working');
			}
		}		
		xml.open('POST', 'php/Blogs.php');
		xml.send(elem);