_('.confirm').onclick = function(){
		alert('Are you sure you want to prescribe this');
		var licence_num = "<?php echo $user;?>";
		var elem = new FormData();
		elem.append("id", _('.id').value);
		elem.append("prescribe", _('.prescribe').value);
		elem.append("presciber_id", licence_num);
		console.log(elem);
		// var xml =  window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject("Microsoft.XMLHTTP");

		// xml.onreadystatechange = function(){
		// 	if (xml.readyState == 4) {
				
		// 		mes.innerHTML = xml.response;
				
		// 		if (xml.responseText.length < 9) {
					
		// 			mes.innerHTML = 'Your Article has been successfully posted';
		// 		}
		// 	}else{
		// 		console.log('not working');
		// 	}
		// }		
		// xml.open('POST', 'php/Blogs.php');
		// xml.send(elem);
	}