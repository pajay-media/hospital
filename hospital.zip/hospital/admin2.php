	



	<div id="table2">
		<table class="visit">
			<p></p>
				<thead>
					<tr>
						<th colspan="3">Patient Consultaion pad</th>
					</tr>
					<tr>
						<th>Symptoms</th>
						<th>Diagnosis</th>
						<th>Treatment plan</th>
					</tr>
				</thead>	
				<tbody>
					<tr>
						<td class="symptoms" contenteditable="true"></td>	
						<td class="diagnosis" contenteditable="true"></td>
						<td class="treatment" contenteditable="true"></td>
					</tr>
					<tr>
						<td class="mess"></td>
						<td colspan="2"><button class="upload">Upload</button></td>
					</tr>
				</tbody>

			
		</table><script>
		$('.upload').click(
								function(){
									var user = "<?php echo $user; ?>";
									var data = $('.symptoms')[0].innerHTML + ',' + $('.diagnosis')[0].innerHTML + ',' + $('.treatment')[0].innerHTML + ',' + user;
									var request = $.ajax({
									  url: "smallPhp/assess.php",
									  method: "POST",
									  data: { data : data },
									  dataType: "text"
									});
									 
									request.done(function( msg ) {
									  $( ".mess" ).html( msg );
									});
									 
									request.fail(function( jqXHR, textStatus ) {
									  alert( "Request failed: " + textStatus );
									});
								}
							);
						</script>