<?php 
require '../asset/php/functions.php';
$name=$_POST['id'];
$namee=htmlentities($name);
$con=new mysqli('localhost','root','','medication');

$searchs=mysqli_query($con,"SELECT * FROM patient");
if ($searchs) {
	while ($find=mysqli_fetch_assoc($searchs)) {
		$nam=$find['name'];
		$cut=substr($nam, 0,3);
		if ($namee==$cut or $namee==$nam) {
			echo $nam;
		}
}

	}
	

/*$query = "SELECT * FROM patient WHERE identity_num = :id_num ORDER BY id DESC LIMIT 1";
$patient = query($query, array('id_num' => $_POST['id']), $conx);
$test = query("SELECT * FROM test WHERE identity_num = :id_num ORDER BY id DESC LIMIT 3",array('id_num' => $_POST['id']), $conx);
$search=mysqli_query($con,"SELECT name, sex, dob FROM patient");
if ($search) {
	while ($key=mysqli_fetch_assoc($search)) {
	$title=$key['name'];
	$cut=substr($nam, 0,3);
	echo $cut;
	if ($namee==$cut) {
		echo "$title";
	}
	}
	
}

else{
	echo "Looking for this patient";

 }*/
?>