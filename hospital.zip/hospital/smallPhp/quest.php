<?php
#require '../asset/php/funct.php';

$con=new mysqli('localhost','root','','medication');

$identity_num = $_POST['identity'];
$ide=htmlentities($identity_num);

$id = explode(':', $identity_num);
//echo $id[1];
$query=mysqli_query($con,"SELECT name, sex, dob FROM patient WHERE identity_num = $ide ORDER BY id DESC");
#$query = "SELECT * FROM patient WHERE identity_num = $ide";


#$req = check($conx,$query);
if ($query) {
	
while ($key=mysqli_fetch_assoc($query)) {
$name=$key['name'];
$age=$key['dob'];
$sex=$key['sex'];
echo "<div style='text-align:center; '>
<p>Patient Name : $name</p><p>Date of Birth : $age</p><p>Sex : $sex</p>
</div>





";
}
}




?>