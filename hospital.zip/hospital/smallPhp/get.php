<?php

require 'asset/php/funct.php';

$id = $_POST['id'];
$query = "SELECT * FROM patient WHERE identity_num = $id ORDER BY id DESC LIMIT 1";
$res = check($conx,$query);
if ($res != 'false') {
	# code...
	echo json_encode($res);
}else{
	echo 'false';
}
?>