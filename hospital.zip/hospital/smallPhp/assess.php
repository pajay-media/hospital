<?php 
header('Content-Type: text/xml'); 
echo '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
echo '<response>'; 
$con=new mysqli('localhost','root','','medication');

$symptoms=$_GET['symptoms'];
$diagnosis=$_GET['diagnosis'];
$treatment=$_GET['treatment'];
$identity=$_GET['identity'];
$user=$_GET['user'];
$sym=htmlentities($symptoms);

$dia=htmlentities($diagnosis);

$trea=htmlentities($treatment);
$ide=htmlentities($identity);
$usr=htmlentities($user);
$date=date('d-m-y');
$dates=htmlentities($date);

$ins=mysqli_query($con,"INSERT INTO assesment (symptom, diagnosis, plan, licence_num, pnumber, dates) VALUES ('$sym','$dia','$trea','$user','$ide','$dates')");

if ($ins) {
	echo "Details inserted by  user: $usr";
}
else{
	echo "error $dates";

}
/*if (!empty($_POST['elem'])) {
	# code...
	$data = explode(',', str_replace('<br>', '', $_POST['data'])) ;
	//insert innot database
	$query = "INSERT INTO assesment (id, symptom, diagnosis, plan, dates, licence_num) VALUES (NULL, :symptom, :diagnosis, :plan, :dates, :licence_num)";
	$get = insert($conx,$query,array('symptom'=> $data[0], 'diagnosis' => $data[1], 'plan' => $data[2], 'dates' => date('d-m-y'), 'licence_num' => $data[3]));
	if ($get != false) {
		# code...
		echo "Good doc";
	}else{
		echo "Unable to upload";
	}
}else{
	echo "Fill al fields for proper assessment of patient";
}*/
echo '</response>';
 ?>