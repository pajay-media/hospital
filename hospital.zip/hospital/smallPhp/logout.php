<?php

session_start();

$_SESSION['user'] = '';
$_SESSION['union'] = '';

session_destroy();

echo "done";


?>