    -- phpMyAdmin SQL Dump
    -- version 4.8.0
    -- https://www.phpmyadmin.net/
    --
    -- Host: 127.0.0.1
    -- Generation Time: Oct 27, 2019 at 03:49 PM
    -- Server version: 10.1.31-MariaDB
    -- PHP Version: 7.2.4

    SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
    SET AUTOCOMMIT = 0;
    START TRANSACTION;
    SET time_zone = "+00:00";


    /*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
    /*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
    /*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
    /*!40101 SET NAMES utf8mb4 */;

    --
    -- Database: `medication`
    --

    -- --------------------------------------------------------

    --
    -- Table structure for table `amd`
    --

    CREATE TABLE `amd` (
      `id` int(10) NOT NULL,
      `name` varchar(20) NOT NULL,
      `licence_num` varchar(10) NOT NULL,
      `sex` varchar(10) NOT NULL,
      `dob` varchar(10) NOT NULL,
      `phone_number` varchar(30) NOT NULL,
      `email` varchar(100) NOT NULL,
      `home_address` varchar(120) NOT NULL,
      `place_of_work` varchar(200) NOT NULL,
      `address_of_place_of_work` varchar(200) NOT NULL,
      `post_held` varchar(20) NOT NULL,
      `picture` varchar(80) NOT NULL,
      `password` varchar(200) NOT NULL,
      `signature` varchar(10) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=latin1;

    --
    -- Dumping data for table `amd`
    --

    INSERT INTO `amd` (`id`, `name`, `licence_num`, `sex`, `dob`, `phone_number`, `email`, `home_address`, `place_of_work`, `address_of_place_of_work`, `post_held`, `picture`, `password`, `signature`) VALUES
    (1, 'Faleye Justina', '09876', 'female', '26-12-1996', '08062620812', 'faleye@yahoo.com\r\n\r\n', 'No 325 FLCHE ilorin Kwara State.', 'University of Jos Teaching Hospital, Plateau State.', 'Along Oke-oyi road, Ilorin Kwara State', 'Resident Doctor', 'kunle', '$2y$10$D6HrkdbJzXttR0gq8rN.MOWc2RI5rTQnzROjG1E9ppH.VpB4Uwk0K', 'just');

    -- --------------------------------------------------------

    --
    -- Table structure for table `assesment`
    --

    CREATE TABLE `assesment` (
      `id` int(10) NOT NULL,
      `symptom` varchar(200) NOT NULL,
      `diagnosis` varchar(200) NOT NULL,
      `plan` varchar(200) NOT NULL,
      `dates` varchar(10) NOT NULL,
      `licence_num` varchar(10) NOT NULL,
      `pnumber` text NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=latin1;

    --
    -- Dumping data for table `assesment`
    --

    INSERT INTO `assesment` (`id`, `symptom`, `diagnosis`, `plan`, `dates`, `licence_num`, `pnumber`) VALUES
    (9, 'gggggg', 'gg', 'ff', '', '09876', '40487'),
    (10, 'jjjjjjjjjjii', 'iioo', '099', '20-09-19', '09876', '12345'),
    (11, 'Hign temperature', 'Typhoid', 'Drip and sugar solution', '20-09-19', '09876', '40487'),
    (12, 'high fever', 'Typhoid', 'paracetamol', '20-09-19', '12345', '40487'),
    (13, 'swollen nose', 'tuberculosis', 'admit and place on heavy', '21-09-19', '12345', '12345'),
    (14, 'cold and cough', 'Catarh and tb', 'administer syrup and also tb vaccine', '21-09-19', '12345', '63637'),
    (15, 'White eyeballs,headache and fever', 'High blood pressure, malaria', 'Treat malaria and prescribed malaria medicine', '21-09-19', '09876', '63637'),
    (16, 'High fever', 'chronic malaria', 'injection and high dose of chloroquine', '25-09-19', '09876', '40487'),
    (17, 'High fever', 'iuuuuuuu', 'oooooooo', '25-09-19', '09876', '66'),
    (18, 'headache, stomache ache', 'Malaria  , and jedi jedi', '1-codein, 2- sukesuke', '26-09-19', '12345', '66'),
    (19, 'headdap', 'ty', 'kioki', '30-09-19', '12345', '12345'),
    (20, 'High Nose discharge', 'Malaria  ', 'Drugs and and adminiaster drip', '02-10-19', '09876', '13845');

    -- --------------------------------------------------------

    --
    -- Table structure for table `patient`
    --

    CREATE TABLE `patient` (
      `id` int(10) NOT NULL,
      `name` varchar(40) NOT NULL,
      `identity_num` varchar(10) NOT NULL,
      `phone` varchar(30) NOT NULL,
      `sex` varchar(10) NOT NULL,
      `dob` varchar(12) NOT NULL,
      `address` varchar(200) NOT NULL,
      `nok_in` varchar(20) NOT NULL,
      `nok_status` varchar(20) NOT NULL,
      `picture` varchar(20) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=latin1;

    --
    -- Dumping data for table `patient`
    --

    INSERT INTO `patient` (`id`, `name`, `identity_num`, `phone`, `sex`, `dob`, `address`, `nok_in`, `nok_status`, `picture`) VALUES
    (1, 'Opadokun Feranmi', '40487', '090897898', 'male', '12-03-1960', 'NO 4 Agbabiaka street kogi', '23412,90876,67643', 'father,wife,daughter', 'plasil'),
    (2, 'Aniyi', '12345', '12345678', 'male', '12-03-2111', 'ilorin', '1111,111', 'single', 'plasil'),
    (13, 'Oluwaseun Ifabiyi Faith', '13845', '09020613845', 'female', '2019-09-13', '2019-09-13', '', '', ''),
    (14, 'Adewale Ayuba', '83119', '09069083119', 'female', '2019-10-13', 'gaakanbi, daniallu, ilorin', '', '', ''),
    (15, 'Olawale', '62095', '07050862095', 'male', '2019-10-16', 'ttt', '', '', '');

    -- --------------------------------------------------------

    --
    -- Table structure for table `pcn`
    --

    CREATE TABLE `pcn` (
      `id` int(10) NOT NULL,
      `name` varchar(60) NOT NULL,
      `licence_num` varchar(10) NOT NULL,
      `sex` varchar(10) NOT NULL,
      `dob` varchar(10) NOT NULL,
      `place_of_work` varchar(100) NOT NULL,
      `address_of_place_of_work` varchar(200) NOT NULL,
      `phone_number` varchar(30) NOT NULL,
      `email` varchar(200) NOT NULL,
      `current_home_address` varchar(200) NOT NULL,
      `post_held` varchar(40) NOT NULL,
      `password` varchar(200) NOT NULL,
      `picture` varchar(120) NOT NULL,
      `signature` varchar(40) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=latin1;

    --
    -- Dumping data for table `pcn`
    --

    INSERT INTO `pcn` (`id`, `name`, `licence_num`, `sex`, `dob`, `place_of_work`, `address_of_place_of_work`, `phone_number`, `email`, `current_home_address`, `post_held`, `password`, `picture`, `signature`) VALUES
    (1, 'Opeyemi Emmanuel', '12345', 'male', '12-03-1960', 'University of Ilorin Teaching Hospital, Kwara State.', 'Along Oke Oyi, Ilorin Kwara State', '07060681466', 'temi325@gmail.com', 'No 10 Dr Jege\'s residence along pipeline, ilorin kwara state', 'Head of unit', '$2y$10$rciLt9Ht.Kjxo7ZU4rscxOlsqOsQhkebOpNB8zQ8WgsT41FRKG296', 'khalifa', '000o.');

    -- --------------------------------------------------------

    --
    -- Table structure for table `prescription`
    --

    CREATE TABLE `prescription` (
      `id` int(10) NOT NULL,
      `prescriber_id` varchar(10) NOT NULL,
      `patient_id` varchar(10) NOT NULL,
      `drugs` varchar(2000) NOT NULL,
      `date_of_prescription` varchar(10) NOT NULL,
      `signature` varchar(10) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=latin1;

    --
    -- Dumping data for table `prescription`
    --

    INSERT INTO `prescription` (`id`, `prescriber_id`, `patient_id`, `drugs`, `date_of_prescription`, `signature`) VALUES
    (37, '12345', '12345', '&lt;/br&gt;', '17-1019-19', '000o.'),
    (38, '12345', '12345', '&lt;/br&gt;', '17-1019-19', '000o.'),
    (39, '12345', '12345', '<br>', '17-1019-19', '000o.'),
    (40, '12345', '12345', 'l', '17-1019-19', '000o.'),
    (41, '12345', '12345', '<br>', '17-1019-19', '000o.'),
    (42, '12345', '12345', '&lt;br&gt;', '17-1019-19', '000o.'),
    (43, '12345', '12345', '&lt;br&gt;', '17-1019-19', '000o.'),
    (44, '12345', '12345', '<br>', '17-1019-19', '000o.'),
    (45, '12345', '12345', '&nbsp;', '17-1019-19', '000o.'),
    (46, '12345', '12345', '&nbsp;', '17-1019-19', '000o.'),
    (47, '12345', '12345', '&nbsp;', '17-1019-19', '000o.'),
    (48, '12345', '12345', 'Paracetamol syrup, drip and also flagie drugs<br>', '17-1019-19', '000o.'),
    (49, '12345', '12345', 'wert<br>', '18-1019-19', '000o.');

    -- --------------------------------------------------------

    --
    -- Table structure for table `test`
    --

    CREATE TABLE `test` (
      `id` int(10) NOT NULL,
      `identity_num` varchar(10) NOT NULL,
      `test` varchar(40) NOT NULL,
      `result` varchar(20) NOT NULL,
      `date` varchar(10) NOT NULL,
      `centre` varchar(60) NOT NULL,
      `centre_id` varchar(10) NOT NULL,
      `technician` varchar(40) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=latin1;

    --
    -- Dumping data for table `test`
    --

    INSERT INTO `test` (`id`, `identity_num`, `test`, `result`, `date`, `centre`, `centre_id`, `technician`) VALUES
    (1, '40487', 'Malaria', 'Negative', '12-09-2018', 'ilorin', '90909', 'Akorede Akolade'),
    (2, '40487', 'BP', '120/90mmHg', '29-07-2018', 'Lagos', '10102', 'Gabriel Jesus');

    -- --------------------------------------------------------

    --
    -- Table structure for table `test_centre`
    --

    CREATE TABLE `test_centre` (
      `id` int(10) NOT NULL,
      `name` varchar(40) NOT NULL,
      `address` varchar(100) NOT NULL,
      `state` varchar(24) NOT NULL,
      `phone` varchar(40) NOT NULL,
      `email` varchar(40) NOT NULL,
      `centre_id` varchar(10) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=latin1;

    --
    -- Dumping data for table `test_centre`
    --

    INSERT INTO `test_centre` (`id`, `name`, `address`, `state`, `phone`, `email`, `centre_id`) VALUES
    (1, 'Tuyil Diagnostic Centre', 'Along Asa Dam road, Ilorin Kwara state.', 'Kwara', '09046763212', 'tuyil@gmaail.com', '90909');

    --
    -- Indexes for dumped tables
    --

    --
    -- Indexes for table `amd`
    --
    ALTER TABLE `amd`
      ADD PRIMARY KEY (`id`),
      ADD UNIQUE KEY `licence_num` (`licence_num`);

    --
    -- Indexes for table `assesment`
    --
    ALTER TABLE `assesment`
      ADD PRIMARY KEY (`id`);

    --
    -- Indexes for table `patient`
    --
    ALTER TABLE `patient`
      ADD PRIMARY KEY (`id`);

    --
    -- Indexes for table `pcn`
    --
    ALTER TABLE `pcn`
      ADD PRIMARY KEY (`id`),
      ADD UNIQUE KEY `licence_num` (`licence_num`);

    --
    -- Indexes for table `prescription`
    --
    ALTER TABLE `prescription`
      ADD PRIMARY KEY (`id`);
    ALTER TABLE `prescription` ADD FULLTEXT KEY `drugs` (`drugs`);

    --
    -- Indexes for table `test`
    --
    ALTER TABLE `test`
      ADD PRIMARY KEY (`id`);

    --
    -- Indexes for table `test_centre`
    --
    ALTER TABLE `test_centre`
      ADD PRIMARY KEY (`id`),
      ADD UNIQUE KEY `centre_id` (`centre_id`);

    --
    -- AUTO_INCREMENT for dumped tables
    --

    --
    -- AUTO_INCREMENT for table `amd`
    --
    ALTER TABLE `amd`
      MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

    --
    -- AUTO_INCREMENT for table `assesment`
    --
    ALTER TABLE `assesment`
      MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

    --
    -- AUTO_INCREMENT for table `patient`
    --
    ALTER TABLE `patient`
      MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

    --
    -- AUTO_INCREMENT for table `pcn`
    --
    ALTER TABLE `pcn`
      MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

    --
    -- AUTO_INCREMENT for table `prescription`
    --
    ALTER TABLE `prescription`
      MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

    --
    -- AUTO_INCREMENT for table `test`
    --
    ALTER TABLE `test`
      MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

    --
    -- AUTO_INCREMENT for table `test_centre`
    --
    ALTER TABLE `test_centre`
      MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
    COMMIT;

    /*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
    /*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
    /*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
