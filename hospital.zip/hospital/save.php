<?php
$pres=$_REQUEST['drug'];
$identity=$_REQUEST['identity_num'];
$patient=$_REQUEST['patient_id'];
$sign=$_REQUEST['signature'];

$date=date('d-my-y');
$con=new mysqli('localhost','root','','medication');

if ($pres==="<br>" or empty($pres) or $pres===" ") {
	echo "sorry, prescription cannot be empty";
}
else {

$insert=mysqli_query($con,"INSERT INTO  prescription (prescriber_id,patient_id,drugs,date_of_prescription,signature) VALUES ('$identity','$patient','$pres','$date','$sign')	");

if ($insert) {
	echo "prescription inserted by user with id: $identity";
}
}

?>