<?php 
header('Content-Type: text/xml'); 
echo '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
echo '<response>'; 

$name=$_REQUEST['name'];

$phone=$_REQUEST['phone'];
$sex=$_REQUEST['sex'];
$address=$_REQUEST['address'];
$dob=$_REQUEST['dob'];

$name1=htmlentities($name);
$phone1=htmlentities($phone);
$sex1=htmlentities($sex);
$address1=htmlentities($address);
$dob1=htmlentities($dob);
$identity1=substr($phone1,6,5);
$con=new mysqli('localhost','root','','medication');

$insert=mysqli_query($con,"INSERT INTO patient (name,identity_num,phone,sex,address,dob) VALUES ('$name1','$identity1','$phone1','$sex1','$address1','$dob1')");
if ($insert) {
	echo "New patient registered with identity number : $identity1 ";}

echo '</response>';

?>


