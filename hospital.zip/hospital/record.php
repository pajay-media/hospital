<?php
session_start();
$url=$_SERVER['REQUEST_URI'];
$id = substr($url, strrpos($url, '?') + 1);
$rep=str_replace('%20',' ', $id);


$con=new mysqli('localhost','root','','medication');
$select=mysqli_query($con,"SELECT * FROM patient WHERE name='$rep'");
if ($rep) {
	while ($key=mysqli_fetch_assoc($select)) {
		$name=$key['name'];
		$identity=$key['identity_num'];
		$phone=$key['phone'];
		$sex=$key['sex'];
		$dob=$key['dob'];
		$address=$key['address'];
		$nok=$key['nok_status'];
	}
}
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	  <!-- Site made with Mobirise Website Builder v4.10.7, https://mobirise.com -->
	  <!-- Site made with Mobirise Website Builder v4.10.7, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Dr who, an online filiing system and epidemic survey environment for medical practitional">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/my-logo-128x115.png" type="image/x-icon">
  <meta name="description" content="Hospital prototype">
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons-bold/mobirise-icons-bold.css">
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="assets/tether/tether.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/socicon/css/styles.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/gallery/style.css">
  <link href="assets/fonts/style.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
</head>
<body style="background:#4ed0e8; color:white; text-align:center;">
	<a class="btn btn-md btn-white-outline display-4" href="admin.php">Go back Home</a></div>
<div style="border: 1px solid white; font-size:15px; text-align: left;">
	<p style="text-align: center;"><strong>Patient information desk</strong></p>
<div>
	<p><strong>Patient Name: </strong><?php echo "$name"; ?></br>
	<strong>Identity number: </strong><?php echo "$identity"; ?></br>
	<strong>Phone: </strong><?php echo "$phone"; ?></br>
	<strong>Sex: </strong><?php echo "$sex"; ?></br>
	<strong>Dob: </strong><?php echo "$dob"; ?></br>
<strong>Address: </strong><?php echo "$address"; ?></br>

	<strong>Family members: </strong><?php echo "$nok"; ?></p></br>


</div>
</div>
<div>
	<h3><u>Patient Diagnostic record</u></h3>
	<div class="container align-center"> 
	<table>
	<thead>
	<tr><th>symptom</th><th>diagnosis</th><th>Treatment administered</th><th> Date</th></tr></thead>
	<?php
$rec=mysqli_query($con,"SELECT * FROM assesment WHERE pnumber='$identity'");
if ($rec) {
while ($see=mysqli_fetch_assoc($rec)) {
	echo "
<tbody>
<tr><td> ".$see['symptom']."</td>

<td>". $see['diagnosis'] ."</td>
<td>".$see['plan']."</td><td>". $see['dates']."</td></tr>
</tbody>";
}
}
	?>
</table>
</div>
<style type="text/css">
	thead,table{
		text-align: center;
		border: 1px solid white;
		margin-bottom: 20px;
	}
	th,td{
	padding-right: 20px;
	}

</style>
</body>
</html>