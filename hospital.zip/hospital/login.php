	<?php

session_start();
require 'asset/php/funct.php';
$union=$_POST['union'];

	# code...

	//verify all the login credentials
	$union = ['PCN', 'AMD'];

	//determine the union
	if (in_array($_POST['union'], $union)) {
		# code...
		$union = $_POST['union'];
		if (!empty($_POST['licence_num'])) {
			# code...
	$licence=$_POST['licence_num'];


			$query = "SELECT * FROM $union WHERE licence_num = $licence ORDER BY id LIMIT 1";
			$req = check($conx,$query);
			if ($req != 'false') {
				# code...
				$_SESSION['user'] = $licence;
				$_SESSION['union'] = $union;
				
				echo "1";

			}else{
				echo "You are not recognised ";
			}
		}else{
			echo "No licence_num entered or enter numbers only";
		}
		
	}else{
		echo "Do not play smart with me DAWG!!!";
	}
	//login appropriately

	//enable session 



?>